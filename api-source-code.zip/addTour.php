<?php

require_once "connectDB.php";
$tourName = $_POST['tourName'];
$oldPrice = $_POST['oldPrice'];
$price = $_POST['price'];
$startTime = $_POST['startTime'];
$time = $_POST['time'];
$fromCity = $_POST['fromCity'];
$toCity = $_POST['toCity'];
$seatQuantity = $_POST['seatQuantity'];
$count = $_POST['count'];
$vat = $_POST['vat'];
// http_response_code(500);
// die('err');
$query = "INSERT INTO tour VALUES(null, '$tourName', '$oldPrice', '$price', '$vat', '$startTime', '$time', '$fromCity', '$toCity', '$seatQuantity', '$count', null)";
if (mysqli_query($connect, $query)) {
    echo "Add tour successfully";
} else{
    http_response_code(500);
	echo "An error occurred. ". $connect->error;
}

?>