<?php
    $to      = "ducthinhtrai@gmail.com";
    $subject = "My title";
    $message = "Hello world";
    $header  =  "From:badauxuquang@gmail.com \r\n";
    // $header .=  "Cc:other@exmaple.com \r\n";

    $success = mail ($to,$subject,$message,$header);

    if( $success == true )
    {
        echo "Đã gửi mail thành công...";
    }
    else
    {
          echo "Không gửi đi được...";
    }
?>