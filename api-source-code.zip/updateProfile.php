<?php
require_once "connectDB.php";

$image = null;
$key = "image";
if (isset($_FILES[$key]) and $_FILES[$key]['error'] == 0) {
    $file = $_FILES[$key];
    $allowType = array('jpg', 'png', 'jpeg');
    $fileType = pathinfo($file["name"],PATHINFO_EXTENSION);
    if (!in_array($fileType,$allowType)) {
        die("Require image is JPG, PNG, JPEG");
    }
    $target_file = "images/". bin2hex(random_bytes(16)). ".". $fileType;
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        $image = $target_file;
    } else {
        die("Update image error");
    }
}

$userId = $_POST['userId'];
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];

$query = "UPDATE user SET name = '$name', phone = '$phone', email = '$email', image = '$image', password = '$password' WHERE id = '$userId'";
if (mysqli_query($connect, $query)) {
    $query = "SELECT * FROM user WHERE id = '$userId' LIMIT 1";
    if ($data = mysqli_query($connect, $query)) {
        if (!empty($user = mysqli_fetch_assoc($data))) {
    	    echo json_encode($user);
        } else {
            http_response_code(500);
            die('An error occurred. User cannot return. '. $connect->error);
        }
    } else {
        http_response_code(500);
        die('An error occurred. '. $connect->error);
    }
} else {
    http_response_code(500);
    die('An error occurred. User cannot update. '. $connect->error);
}

?>