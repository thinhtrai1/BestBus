<?php

class Deal {
	function Deal($id, $discount, $description, $image) {
		$this -> id = $id;
		$this -> discount = $discount;
		$this -> description = $description;
		$this -> image = $image;
	}
}

$deals = array();
array_push($deals, new Deal(0, 20, "Only available every Wednesday and Thursday", "images/deal_1.jpg"));
array_push($deals, new Deal(1, 40, "October 31st is coming. Have fun with friends on Halloween", "images/deal_2.jpeg"));
array_push($deals, new Deal(2, 99, "Tet has come and you missed the buses go home. Don't worried. We are always with you at all times", "images/deal_3.jpg"));

header('Content-type: application/json');
echo json_encode($deals);

?>