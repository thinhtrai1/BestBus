<?php

require_once "connectDB.php";

$from = htmlspecialchars($_GET["from"]);
$to = htmlspecialchars($_GET["to"]);
$data = mysqli_query($connect, "SELECT * FROM tour WHERE fromCity LIKE '%$from%' AND toCity LIKE '%$to%' ORDER BY startTime");

if(!$data){
    http_response_code(500);
    die('An error occurred' .$connect->error);
}

$arrayTour = array();
while ($row = mysqli_fetch_assoc($data)) {
    $row["seatSelected"] = json_decode($row["seatSelected"]);
	array_push($arrayTour, $row);
}
echo json_encode($arrayTour);

?>